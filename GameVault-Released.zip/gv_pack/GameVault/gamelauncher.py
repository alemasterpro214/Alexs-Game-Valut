#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GameVault — launcher di giochi (Windows + Linux)
Libreria con ricerca, preferiti, cartelle; impostazioni con lingua (11) e sfondo sfocato.
I collegamenti restano salvati tra le sessioni. Non permette di disinstallare i giochi.

Uso:
    python gamelauncher.py            avvia la GUI
    python gamelauncher.py --selftest esegue i test non-GUI ed esce
"""

import argparse
import base64
import io
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import threading
import webbrowser
import datetime

IS_WINDOWS = platform.system() == "Windows"

# ---------------------------------------------------------------- console
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, OSError):
    pass

# ---------------------------------------------------------------- dipendenze
try:
    import tkinter as tk
    from tkinter import ttk, filedialog, simpledialog, messagebox
    TK_OK = True
except ImportError:
    TK_OK = False

try:
    from PIL import Image, ImageTk, ImageFilter
    PIL_OK = True
except ImportError:
    PIL_OK = False

try:
    from icoextract import IconExtractor
    ICOEXTRACT_OK = True
except ImportError:
    ICOEXTRACT_OK = False

APP_NAME = "GameVault"
CONFIG_DIR_NAME = ".gamevault"


def config_dir() -> str:
    """Cartella dati persistente (~/.gamevault)."""
    base = os.environ.get(
        "APPDATA" if IS_WINDOWS else "HOME",
        os.path.expanduser("~"),
    )
    # su Windows usiamo direttamente la Home per semplicita' cross-platform
    d = os.path.join(os.path.expanduser("~"), CONFIG_DIR_NAME)
    os.makedirs(d, exist_ok=True)
    return d


def config_path() -> str:
    return os.path.join(config_dir(), "library.json")


DB_TRUE = True


# =====================================================================
# i18n — 11 lingue
# =====================================================================
I18N = {
    "en": {
        "app_title": "GameVault",
        "library": "Library",
        "settings": "Settings",
        "search": "Search games…",
        "add_game": "Add game",
        "add_game_title": "Add game",
        "choose_exe": "Step 1/3 - Executable or shortcut",
        "choose_exe_help": "Select the game executable (.exe), shortcut (.lnk/.url) or Linux binary/script",
        "browse": "Browse…",
        "choose_icon": "Step 2/3 - Icon",
        "icon_auto": "Auto (from executable)",
        "icon_file": "Choose image…",
        "choose_name": "Step 3/3 - Game name",
        "name_label": "Name",
        "folder_label": "Folder",
        "no_folder": "No folder",
        "save": "Save",
        "cancel": "Cancel",
        "favorites_only": "Favorites",
        "all": "All",
        "favorite": "Favorite",
        "unfavorite": "Unfavorite",
        "edit": "Edit",
        "remove": "Remove",
        "remove_confirm": "Remove \"{name}\" (link only, the game is not uninstalled)?",
        "edit_title": "Edit game",
        "new_folder": "New folder…",
        "folders": "Folders",
        "manage_folders": "Manage folders…",
        "rename_folder": "Rename folder",
        "delete_folder": "Delete folder",
        "delete_folder_confirm": "Delete folder \"{name}\"? Games will be kept (no folder).",
        "language": "Language",
        "background": "Background image",
        "change_bg": "Choose image…",
        "remove_bg": "Remove background",
        "bg_info": "Shown blurred behind the UI.",
        "data_note": "Links are stored in {path}. Games are NEVER uninstalled by this app.",
        "no_results": "No games found",
        "error_generic": "Error",
        "err_missing_exe": "Please select an executable or shortcut.",
        "err_bad_name": "Please enter a name.",
        "icon_extract_fail": "No icon found in the executable; choose an image.",
        "launch_fail": "Could not launch: {path}",
        "renamed_env": "Language applied.",
        "ok": "OK",
        "yes": "Yes",
        "no": "No",
        "add": "Add",
        "close": "Close",
        "filter_label": "Filter",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "Recent",
        "run_count": "Runs: {n}",
        "last_run": "Last run: {t}",
        "never": "never",
        "about": "About",
        "folders_help": "Right-click a folder to rename/delete it.",
        "selftest_header": "GameVault selftest",
    },
    "it": {
        "app_title": "GameVault",
        "library": "Libreria",
        "settings": "Impostazioni",
        "search": "Cerca giochi…",
        "add_game": "Aggiungi gioco",
        "add_game_title": "Aggiungi gioco",
        "choose_exe": "Passo 1/3 - Eseguibile o collegamento",
        "choose_exe_help": "Seleziona l'eseguibile del gioco (.exe), un collegamento (.lnk/.url) o un binario/script Linux",
        "browse": "Sfoglia…",
        "choose_icon": "Passo 2/3 - Icona",
        "icon_auto": "Automatica (dall'eseguibile)",
        "icon_file": "Scegli immagine…",
        "choose_name": "Passo 3/3 - Nome del gioco",
        "name_label": "Nome",
        "folder_label": "Cartella",
        "no_folder": "Nessuna cartella",
        "save": "Salva",
        "cancel": "Annulla",
        "favorites_only": "Preferiti",
        "all": "Tutti",
        "favorite": "Preferito",
        "unfavorite": "Non preferito",
        "edit": "Modifica",
        "remove": "Rimuovi",
        "remove_confirm": "Rimuovere \"{name}\" (solo il collegamento, il gioco NON viene disinstallato)?",
        "edit_title": "Modifica gioco",
        "new_folder": "Nuova cartella…",
        "folders": "Cartelle",
        "manage_folders": "Gestisci cartelle…",
        "rename_folder": "Rinomina cartella",
        "delete_folder": "Elimina cartella",
        "delete_folder_confirm": "Eliminare la cartella \"{name}\"? I giochi restano (senza cartella).",
        "language": "Lingua",
        "background": "Immagine di sfondo",
        "change_bg": "Scegli immagine…",
        "remove_bg": "Rimuovi sfondo",
        "bg_info": "Verrà mostrata sfocata dietro l'interfaccia.",
        "data_note": "Collegamenti salvati in {path}. Quest'app NON disinstalla mai i giochi.",
        "no_results": "Nessun gioco trovato",
        "error_generic": "Errore",
        "err_missing_exe": "Seleziona un eseguibile o un collegamento.",
        "err_bad_name": "Inserisci un nome.",
        "icon_extract_fail": "Nessuna icona trovata nell'eseguibile; scegli un'immagine.",
        "launch_fail": "Impossibile avviare: {path}",
        "renamed_env": "Lingua applicata.",
        "ok": "OK",
        "yes": "Sì",
        "no": "No",
        "add": "Aggiungi",
        "close": "Chiudi",
        "filter_label": "Filtro",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "Recenti",
        "run_count": "Avvii: {n}",
        "last_run": "Ultimo avvio: {t}",
        "never": "mai",
        "about": "Informazioni",
        "folders_help": "Clic destro su una cartella per rinomina/elimina.",
        "selftest_header": "GameVault selftest",
    },
    "de": {
        "app_title": "GameVault",
        "library": "Bibliothek",
        "settings": "Einstellungen",
        "search": "Spiele suchen…",
        "add_game": "Spiel hinzufügen",
        "add_game_title": "Spiel hinzufügen",
        "choose_exe": "Schritt 1/3 - Programm oder Verknüpfung",
        "choose_exe_help": "Wähle die Spieldatei (.exe), Verknüpfung (.lnk/.url) oder Linux-Binärdatei/Skript",
        "browse": "Durchsuchen…",
        "choose_icon": "Schritt 2/3 - Symbol",
        "icon_auto": "Automatisch (vom Programm)",
        "icon_file": "Bild auswählen…",
        "choose_name": "Schritt 3/3 - Spielname",
        "name_label": "Name",
        "folder_label": "Ordner",
        "no_folder": "Kein Ordner",
        "save": "Speichern",
        "cancel": "Abbrechen",
        "favorites_only": "Favoriten",
        "all": "Alle",
        "favorite": "Favorit",
        "unfavorite": "Kein Favorit",
        "edit": "Bearbeiten",
        "remove": "Entfernen",
        "remove_confirm": "\"{name}\" entfernen (nur Verknüpfung; Spiel wird NICHT deinstalliert)?",
        "edit_title": "Spiel bearbeiten",
        "new_folder": "Neuer Ordner…",
        "folders": "Ordner",
        "manage_folders": "Ordner verwalten…",
        "rename_folder": "Ordner umbenennen",
        "delete_folder": "Ordner löschen",
        "delete_folder_confirm": "Ordner \"{name}\" löschen? Spiele bleiben (ohne Ordner).",
        "language": "Sprache",
        "background": "Hintergrundbild",
        "change_bg": "Bild auswählen…",
        "remove_bg": "Hintergrund entfernen",
        "bg_info": "Wird unscharf hinter der Oberfläche angezeigt.",
        "data_note": "Verknüpfungen gespeichert in {path}. Dieses Programm deinstalliert NIE Spiele.",
        "no_results": "Keine Spiele gefunden",
        "error_generic": "Fehler",
        "err_missing_exe": "Bitte Programm oder Verknüpfung auswählen.",
        "err_bad_name": "Bitte einen Namen eingeben.",
        "icon_extract_fail": "Kein Symbol gefunden; bitte Bild auswählen.",
        "launch_fail": "Start fehlgeschlagen: {path}",
        "renamed_env": "Sprache angewendet.",
        "ok": "OK",
        "yes": "Ja",
        "no": "Nein",
        "add": "Hinzufügen",
        "close": "Schließen",
        "filter_label": "Filter",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "Neueste",
        "run_count": "Starts: {n}",
        "last_run": "Zuletzt gestartet: {t}",
        "never": "nie",
        "about": "Über",
        "folders_help": "Rechtsklick auf Ordner: umbenennen/löschen.",
        "selftest_header": "GameVault Selbsttest",
    },
    "fr": {
        "app_title": "GameVault",
        "library": "Bibliothèque",
        "settings": "Paramètres",
        "search": "Rechercher des jeux…",
        "add_game": "Ajouter un jeu",
        "add_game_title": "Ajouter un jeu",
        "choose_exe": "Étape 1/3 - Exécutable ou raccourci",
        "choose_exe_help": "Sélectionnez l'exécutable du jeu (.exe), un raccourci (.lnk/.url) ou un binaire/script Linux",
        "browse": "Parcourir…",
        "choose_icon": "Étape 2/3 - Icône",
        "icon_auto": "Automatique (depuis l'exécutable)",
        "icon_file": "Choisir une image…",
        "choose_name": "Étape 3/3 - Nom du jeu",
        "name_label": "Nom",
        "folder_label": "Dossier",
        "no_folder": "Aucun dossier",
        "save": "Enregistrer",
        "cancel": "Annuler",
        "favorites_only": "Favoris",
        "all": "Tous",
        "favorite": "Favori",
        "unfavorite": "Non favori",
        "edit": "Modifier",
        "remove": "Retirer",
        "remove_confirm": "Retirer \"{name}\" (lien seulement ; le jeu n'est PAS désinstallé) ?",
        "edit_title": "Modifier le jeu",
        "new_folder": "Nouveau dossier…",
        "folders": "Dossiers",
        "manage_folders": "Gérer les dossiers…",
        "rename_folder": "Renommer le dossier",
        "delete_folder": "Supprimer le dossier",
        "delete_folder_confirm": "Supprimer le dossier \"{name}\" ? Les jeux restent (sans dossier).",
        "language": "Langue",
        "background": "Image de fond",
        "change_bg": "Choisir une image…",
        "remove_bg": "Retirer le fond",
        "bg_info": "Affichée floutée derrière l'interface.",
        "data_note": "Liens enregistrés dans {path}. Cette app ne désinstalle JAMAIS les jeux.",
        "no_results": "Aucun jeu trouvé",
        "error_generic": "Erreur",
        "err_missing_exe": "Veuillez sélectionner un exécutable ou un raccourci.",
        "err_bad_name": "Veuillez saisir un nom.",
        "icon_extract_fail": "Aucune icône trouvée ; choisissez une image.",
        "launch_fail": "Impossible de lancer : {path}",
        "renamed_env": "Langue appliquée.",
        "ok": "OK",
        "yes": "Oui",
        "no": "Non",
        "add": "Ajouter",
        "close": "Fermer",
        "filter_label": "Filtre",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "Récents",
        "run_count": "Lancements : {n}",
        "last_run": "Dernier lancement : {t}",
        "never": "jamais",
        "about": "À propos",
        "folders_help": "Clic droit sur un dossier : renommer/supprimer.",
        "selftest_header": "GameVault autotest",
    },
    "es": {
        "app_title": "GameVault",
        "library": "Biblioteca",
        "settings": "Ajustes",
        "search": "Buscar juegos…",
        "add_game": "Añadir juego",
        "add_game_title": "Añadir juego",
        "choose_exe": "Paso 1/3 - Ejecutable o acceso directo",
        "choose_exe_help": "Selecciona el ejecutable del juego (.exe), un acceso directo (.lnk/.url) o un binario/script de Linux",
        "browse": "Explorar…",
        "choose_icon": "Paso 2/3 - Icono",
        "icon_auto": "Automático (del ejecutable)",
        "icon_file": "Elegir imagen…",
        "choose_name": "Paso 3/3 - Nombre del juego",
        "name_label": "Nombre",
        "folder_label": "Carpeta",
        "no_folder": "Sin carpeta",
        "save": "Guardar",
        "cancel": "Cancelar",
        "favorites_only": "Favoritos",
        "all": "Todos",
        "favorite": "Favorito",
        "unfavorite": "No favorito",
        "edit": "Editar",
        "remove": "Quitar",
        "remove_confirm": "¿Quitar \"{name}\"? (solo el enlace; el juego NO se desinstala)",
        "edit_title": "Editar juego",
        "new_folder": "Nueva carpeta…",
        "folders": "Carpetas",
        "manage_folders": "Gestionar carpetas…",
        "rename_folder": "Renombrar carpeta",
        "delete_folder": "Eliminar carpeta",
        "delete_folder_confirm": "¿Eliminar la carpeta \"{name}\"? Los juegos permanecen (sin carpeta).",
        "language": "Idioma",
        "background": "Imagen de fondo",
        "change_bg": "Elegir imagen…",
        "remove_bg": "Quitar fondo",
        "bg_info": "Se muestra desenfocada detrás de la interfaz.",
        "data_note": "Enlaces guardados en {path}. Esta app NUNCA desinstala juegos.",
        "no_results": "No se encontraron juegos",
        "error_generic": "Error",
        "err_missing_exe": "Selecciona un ejecutable o acceso directo.",
        "err_bad_name": "Escribe un nombre.",
        "icon_extract_fail": "Sin icono en el ejecutable; elige una imagen.",
        "launch_fail": "No se pudo iniciar: {path}",
        "renamed_env": "Idioma aplicado.",
        "ok": "OK",
        "yes": "Sí",
        "no": "No",
        "add": "Añadir",
        "close": "Cerrar",
        "filter_label": "Filtro",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "Recientes",
        "run_count": "Ejecuciones: {n}",
        "last_run": "Última: {t}",
        "never": "nunca",
        "about": "Acerca de",
        "folders_help": "Clic derecho en carpeta: renombrar/eliminar.",
        "selftest_header": "GameVault autotest",
    },
    "ru": {
        "app_title": "GameVault",
        "library": "Библиотека",
        "settings": "Настройки",
        "search": "Поиск игр…",
        "add_game": "Добавить игру",
        "add_game_title": "Добавить игру",
        "choose_exe": "Шаг 1/3 - Исполняемый файл или ярлык",
        "choose_exe_help": "Выберите файл игры (.exe), ярлык (.lnk/.url) или бинарник/скрипт Linux",
        "browse": "Обзор…",
        "choose_icon": "Шаг 2/3 - Значок",
        "icon_auto": "Автоматически (из файла)",
        "icon_file": "Выбрать изображение…",
        "choose_name": "Шаг 3/3 - Название игры",
        "name_label": "Название",
        "folder_label": "Папка",
        "no_folder": "Без папки",
        "save": "Сохранить",
        "cancel": "Отмена",
        "favorites_only": "Избранное",
        "all": "Все",
        "favorite": "Избранное",
        "unfavorite": "Убрать",
        "edit": "Изменить",
        "remove": "Удалить",
        "remove_confirm": "Удалить \"{name}\" (только ярлык; игра НЕ удаляется)?",
        "edit_title": "Изменение игры",
        "new_folder": "Новая папка…",
        "folders": "Папки",
        "manage_folders": "Управление папками…",
        "rename_folder": "Переименовать папку",
        "delete_folder": "Удалить папку",
        "delete_folder_confirm": "Удалить папку \"{name}\"? Игры сохранятся (без папки).",
        "language": "Язык",
        "background": "Фоновое изображение",
        "change_bg": "Выбрать изображение…",
        "remove_bg": "Убрать фон",
        "bg_info": "Отображается размытым за интерфейсом.",
        "data_note": "Ссылки сохраняются в {path}. Приложение НИКОГДА не удаляет игры.",
        "no_results": "Игры не найдены",
        "error_generic": "Ошибка",
        "err_missing_exe": "Выберите исполняемый файл или ярлык.",
        "err_bad_name": "Введите название.",
        "icon_extract_fail": "Значок не найден; выберите изображение.",
        "launch_fail": "Не удалось запустить: {path}",
        "renamed_env": "Язык применён.",
        "ok": "ОК",
        "yes": "Да",
        "no": "Нет",
        "add": "Добавить",
        "close": "Закрыть",
        "filter_label": "Фильтр",
        "sort_az": "А-Я",
        "sort_za": "Я-А",
        "sort_recent": "Недавние",
        "run_count": "Запусков: {n}",
        "last_run": "Последний: {t}",
        "never": "никогда",
        "about": "О программе",
        "folders_help": "Правый клик по папке: переименовать/удалить.",
        "selftest_header": "GameVault самотест",
    },
    "hi": {
        "app_title": "GameVault",
        "library": "लाइब्रेरी",
        "settings": "सेटिंग्स",
        "search": "गेम खोजें…",
        "add_game": "गेम जोड़ें",
        "add_game_title": "गेम जोड़ें",
        "choose_exe": "चरण 1/3 - एक्ज़ीक्यूटेबल या शॉर्टकट",
        "choose_exe_help": "गेम की फ़ाइल (.exe), शॉर्टकट (.lnk/.url) या Linux बाइनरी/स्क्रिप्ट चुनें",
        "browse": "ब्राउज़…",
        "choose_icon": "चरण 2/3 - आइकन",
        "icon_auto": "स्वचालित (एक्ज़ीक्यूटेबल से)",
        "icon_file": "चित्र चुनें…",
        "choose_name": "चरण 3/3 - गेम का नाम",
        "name_label": "नाम",
        "folder_label": "फ़ोल्डर",
        "no_folder": "कोई फ़ोल्डर नहीं",
        "save": "सहेजें",
        "cancel": "रद्द करें",
        "favorites_only": "पसंदीदा",
        "all": "सभी",
        "favorite": "पसंदीदा",
        "unfavorite": "हटाएँ",
        "edit": "संपादित करें",
        "remove": "हटाएँ",
        "remove_confirm": "\"{name}\" हटाएँ? (केवल लिंक; गेम अनइंस्टॉल नहीं होगा)",
        "edit_title": "गेम संपादित करें",
        "new_folder": "नया फ़ोल्डर…",
        "folders": "फ़ोल्डर",
        "manage_folders": "फ़ोल्डर प्रबंधित करें…",
        "rename_folder": "फ़ोल्डर का नाम बदलें",
        "delete_folder": "फ़ोल्डर हटाएँ",
        "delete_folder_confirm": "फ़ोल्डर \"{name}\" हटाएँ? गेम सुरक्षित रहेंगे।",
        "language": "भाषा",
        "background": "पृष्ठभूमि चित्र",
        "change_bg": "चित्र चुनें…",
        "remove_bg": "पृष्ठभूमि हटाएँ",
        "bg_info": "इंटरफ़ेस के पीछे धुंधली दिखाई देगी।",
        "data_note": "लिंक {path} में सहेजे जाते हैं। यह ऐप गेम कभी अनइंस्टॉल नहीं करती।",
        "no_results": "कोई गेम नहीं मिला",
        "error_generic": "त्रुटि",
        "err_missing_exe": "कृपया एक्ज़ीक्यूटेबल या शॉर्टकट चुनें।",
        "err_bad_name": "कृपया नाम दर्ज करें।",
        "icon_extract_fail": "आइकन नहीं मिला; चित्र चुनें।",
        "launch_fail": "लॉन्च विफल: {path}",
        "renamed_env": "भाषा लागू।",
        "ok": "ठीक",
        "yes": "हाँ",
        "no": "नहीं",
        "add": "जोड़ें",
        "close": "बंद करें",
        "filter_label": "फ़िल्टर",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "हाल के",
        "run_count": "लॉन्च: {n}",
        "last_run": "अंतिम: {t}",
        "never": "कभी नहीं",
        "about": "परिचय",
        "folders_help": "फ़ोल्डर पर राइट-क्लिक: नाम बदलें/हटाएँ।",
        "selftest_header": "GameVault स्वयं-परीक्षण",
    },
    "ko": {
        "app_title": "GameVault",
        "library": "라이브러리",
        "settings": "설정",
        "search": "게임 검색…",
        "add_game": "게임 추가",
        "add_game_title": "게임 추가",
        "choose_exe": "단계 1/3 - 실행 파일 또는 바로 가기",
        "choose_exe_help": "게임 실행 파일(.exe), 바로 가기(.lnk/.url) 또는 리눅스 바이너리/스크립트 선택",
        "browse": "찾아보기…",
        "choose_icon": "단계 2/3 - 아이콘",
        "icon_auto": "자동 (실행 파일에서)",
        "icon_file": "이미지 선택…",
        "choose_name": "단계 3/3 - 게임 이름",
        "name_label": "이름",
        "folder_label": "폴더",
        "no_folder": "폴더 없음",
        "save": "저장",
        "cancel": "취소",
        "favorites_only": "즐겨찾기",
        "all": "전체",
        "favorite": "즐겨찾기",
        "unfavorite": "해제",
        "edit": "편집",
        "remove": "제거",
        "remove_confirm": "\"{name}\"을(를) 제거할까요? (링크만; 게임은 삭제되지 않음)",
        "edit_title": "게임 편집",
        "new_folder": "새 폴더…",
        "folders": "폴더",
        "manage_folders": "폴더 관리…",
        "rename_folder": "폴더 이름 바꾸기",
        "delete_folder": "폴더 삭제",
        "delete_folder_confirm": "폴더 \"{name}\"을(를) 삭제할까요? 게임은 유지됩니다.",
        "language": "언어",
        "background": "배경 이미지",
        "change_bg": "이미지 선택…",
        "remove_bg": "배경 제거",
        "bg_info": "인터페이스 뒤에 흐리게 표시됩니다.",
        "data_note": "링크는 {path}에 저장됩니다. 이 앱은 게임을 절대 삭제하지 않습니다.",
        "no_results": "게임이 없습니다",
        "error_generic": "오류",
        "err_missing_exe": "실행 파일 또는 바로 가기를 선택하세요.",
        "err_bad_name": "이름을 입력하세요.",
        "icon_extract_fail": "아이콘을 찾을 수 없습니다; 이미지를 선택하세요.",
        "launch_fail": "실행 실패: {path}",
        "renamed_env": "언어가 적용되었습니다.",
        "ok": "확인",
        "yes": "예",
        "no": "아니오",
        "add": "추가",
        "close": "닫기",
        "filter_label": "필터",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "최근",
        "run_count": "실행: {n}회",
        "last_run": "마지막: {t}",
        "never": "없음",
        "about": "정보",
        "folders_help": "폴더 우클릭: 이름 바꾸기/삭제.",
        "selftest_header": "GameVault 자가 테스트",
    },
    "zh": {
        "app_title": "GameVault",
        "library": "游戏库",
        "settings": "设置",
        "search": "搜索游戏…",
        "add_game": "添加游戏",
        "add_game_title": "添加游戏",
        "choose_exe": "第 1/3 步 - 可执行文件或快捷方式",
        "choose_exe_help": "选择游戏可执行文件（.exe）、快捷方式（.lnk/.url）或 Linux 二进制/脚本",
        "browse": "浏览…",
        "choose_icon": "第 2/3 步 - 图标",
        "icon_auto": "自动（从可执行文件提取）",
        "icon_file": "选择图片…",
        "choose_name": "第 3/3 步 - 游戏名称",
        "name_label": "名称",
        "folder_label": "文件夹",
        "no_folder": "无文件夹",
        "save": "保存",
        "cancel": "取消",
        "favorites_only": "收藏",
        "all": "全部",
        "favorite": "收藏",
        "unfavorite": "取消收藏",
        "edit": "编辑",
        "remove": "移除",
        "remove_confirm": "移除“{name}”？（仅链接，游戏不会被卸载）",
        "edit_title": "编辑游戏",
        "new_folder": "新建文件夹…",
        "folders": "文件夹",
        "manage_folders": "管理文件夹…",
        "rename_folder": "重命名文件夹",
        "delete_folder": "删除文件夹",
        "delete_folder_confirm": "删除文件夹“{name}”？游戏将保留（无文件夹）。",
        "language": "语言",
        "background": "背景图片",
        "change_bg": "选择图片…",
        "remove_bg": "移除背景",
        "bg_info": "将以模糊效果显示在界面后面。",
        "data_note": "链接保存在 {path}。本应用绝不会卸载游戏。",
        "no_results": "未找到游戏",
        "error_generic": "错误",
        "err_missing_exe": "请选择可执行文件或快捷方式。",
        "err_bad_name": "请输入名称。",
        "icon_extract_fail": "未找到图标；请选择图片。",
        "launch_fail": "无法启动：{path}",
        "renamed_env": "语言已应用。",
        "ok": "确定",
        "yes": "是",
        "no": "否",
        "add": "添加",
        "close": "关闭",
        "filter_label": "筛选",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "最近",
        "run_count": "启动：{n} 次",
        "last_run": "上次：{t}",
        "never": "从未",
        "about": "关于",
        "folders_help": "右键文件夹：重命名/删除。",
        "selftest_header": "GameVault 自检",
    },
    "ja": {
        "app_title": "GameVault",
        "library": "ライブラリ",
        "settings": "設定",
        "search": "ゲームを検索…",
        "add_game": "ゲームを追加",
        "add_game_title": "ゲームを追加",
        "choose_exe": "ステップ 1/3 - 実行ファイルまたはショートカット",
        "choose_exe_help": "ゲームの実行ファイル（.exe）、ショートカット（.lnk/.url）、Linux バイナリ/スクリプトを選択",
        "browse": "参照…",
        "choose_icon": "ステップ 2/3 - アイコン",
        "icon_auto": "自動（実行ファイルから）",
        "icon_file": "画像を選択…",
        "choose_name": "ステップ 3/3 - ゲーム名",
        "name_label": "名前",
        "folder_label": "フォルダ",
        "no_folder": "フォルダなし",
        "save": "保存",
        "cancel": "キャンセル",
        "favorites_only": "お気に入り",
        "all": "すべて",
        "favorite": "お気に入り",
        "unfavorite": "解除",
        "edit": "編集",
        "remove": "削除",
        "remove_confirm": "「{name}」を削除しますか？（リンクのみ。ゲームはアンインストールされません）",
        "edit_title": "ゲームを編集",
        "new_folder": "新しいフォルダ…",
        "folders": "フォルダ",
        "manage_folders": "フォルダを管理…",
        "rename_folder": "フォルダ名を変更",
        "delete_folder": "フォルダを削除",
        "delete_folder_confirm": "フォルダ「{name}」を削除しますか？ゲームは保持されます。",
        "language": "言語",
        "background": "背景画像",
        "change_bg": "画像を選択…",
        "remove_bg": "背景を削除",
        "bg_info": "インターフェースの背後にぼかして表示されます。",
        "data_note": "リンクは {path} に保存されます。このアプリはゲームをアンインストールしません。",
        "no_results": "ゲームが見つかりません",
        "error_generic": "エラー",
        "err_missing_exe": "実行ファイルまたはショートカットを選択してください。",
        "err_bad_name": "名前を入力してください。",
        "icon_extract_fail": "アイコンが見つかりません。画像を選択してください。",
        "launch_fail": "起動できませんでした: {path}",
        "renamed_env": "言語を適用しました。",
        "ok": "OK",
        "yes": "はい",
        "no": "いいえ",
        "add": "追加",
        "close": "閉じる",
        "filter_label": "フィルタ",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "最近",
        "run_count": "起動回数: {n}",
        "last_run": "最終起動: {t}",
        "never": "なし",
        "about": "情報",
        "folders_help": "フォルダを右クリック: 名前変更/削除。",
        "selftest_header": "GameVault セルフテスト",
    },
    "pt": {
        "app_title": "GameVault",
        "library": "Biblioteca",
        "settings": "Configurações",
        "search": "Pesquisar jogos…",
        "add_game": "Adicionar jogo",
        "add_game_title": "Adicionar jogo",
        "choose_exe": "Passo 1/3 - Executável ou atalho",
        "choose_exe_help": "Selecione o executável do jogo (.exe), atalho (.lnk/.url) ou binário/script Linux",
        "browse": "Procurar…",
        "choose_icon": "Passo 2/3 - Ícone",
        "icon_auto": "Automático (do executável)",
        "icon_file": "Escolher imagem…",
        "choose_name": "Passo 3/3 - Nome do jogo",
        "name_label": "Nome",
        "folder_label": "Pasta",
        "no_folder": "Sem pasta",
        "save": "Salvar",
        "cancel": "Cancelar",
        "favorites_only": "Favoritos",
        "all": "Todos",
        "favorite": "Favorito",
        "unfavorite": "Remover",
        "edit": "Editar",
        "remove": "Remover",
        "remove_confirm": "Remover \"{name}\"? (apenas o atalho; o jogo NÃO é desinstalado)",
        "edit_title": "Editar jogo",
        "new_folder": "Nova pasta…",
        "folders": "Pastas",
        "manage_folders": "Gerenciar pastas…",
        "rename_folder": "Renomear pasta",
        "delete_folder": "Excluir pasta",
        "delete_folder_confirm": "Excluir a pasta \"{name}\"? Os jogos permanecem (sem pasta).",
        "language": "Idioma",
        "background": "Imagem de fundo",
        "change_bg": "Escolher imagem…",
        "remove_bg": "Remover fundo",
        "bg_info": "Exibida desfocada atrás da interface.",
        "data_note": "Atalhos salvos em {path}. Este app NUNCA desinstala jogos.",
        "no_results": "Nenhum jogo encontrado",
        "error_generic": "Erro",
        "err_missing_exe": "Selecione um executável ou atalho.",
        "err_bad_name": "Digite um nome.",
        "icon_extract_fail": "Sem ícone no executável; escolha uma imagem.",
        "launch_fail": "Falha ao iniciar: {path}",
        "renamed_env": "Idioma aplicado.",
        "ok": "OK",
        "yes": "Sim",
        "no": "Não",
        "add": "Adicionar",
        "close": "Fechar",
        "filter_label": "Filtro",
        "sort_az": "A-Z",
        "sort_za": "Z-A",
        "sort_recent": "Recentes",
        "run_count": "Execuções: {n}",
        "last_run": "Última: {t}",
        "never": "nunca",
        "about": "Sobre",
        "folders_help": "Clique direito na pasta: renomear/excluir.",
        "selftest_header": "GameVault autoteste",
    },
}

LANGUAGE_NAMES = {
    "en": "English",
    "it": "Italiano",
    "de": "Deutsch",
    "fr": "Français",
    "es": "Español",
    "ru": "Русский",
    "hi": "हिन्दी",
    "ko": "한국어",
    "zh": "中文",
    "ja": "日本語",
    "pt": "Português",
}


# =====================================================================
# Persistenza
# =====================================================================
def load_db() -> dict:
    try:
        with open(config_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            data.setdefault("games", [])
            data.setdefault("folders", [])
            data.setdefault("settings", {})
            return data
    except FileNotFoundError:
        pass
    except (json.JSONDecodeError, OSError):
        pass
    return {"games": [], "folders": [], "settings": {}}


def save_db(db: dict) -> None:
    tmp = config_path() + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
        os.replace(tmp, config_path())
    except OSError:
        try:
            os.remove(tmp)
        except OSError:
            pass


# =====================================================================
# Utility di sistema
# =====================================================================
def resolve_target(path: str) -> str:
    """Ritorna l'eseguibile reale a partire da un collegamento."""
    p = path
    low = p.lower()
    if IS_WINDOWS and low.endswith(".lnk"):
        # .lnk: WScript.Shell richiede un percorso ASSOLUTO, quindi risolviamo
        # prima rispetto alla exec dir; comando base64 = niente problemi di quoting
        try:
            ps_cmd = (
                "$p=Join-Path (Get-Location) -ChildPath '" + p.replace("'", "''")
                + "';"
                "$p=[System.IO.Path]::GetFullPath($p);"
                "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($p);"
                "if($s.TargetPath){Write-Output $s.TargetPath}"
            )
            enc = base64.b64encode(ps_cmd.encode("utf-16-le")).decode("ascii")
            ps = subprocess.run(
                ["powershell", "-NoProfile", "-EncodedCommand", enc],
                capture_output=True, text=True, timeout=10,
            )
            if ps.returncode == 0 and ps.stdout.strip():
                return ps.stdout.strip()
        except Exception:
            pass
    if low.endswith(".url"):
        try:
            with open(p, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    if line.lower().startswith("url="):
                        return line[4:].strip()
        except OSError:
            pass
    return p


def _shell_open(target: str, cwd: str):
    """Fallback universale: apre QUALSIASI file con il gestore predefinito
    di Windows (come un doppio clic in Esplora), mantenendo la CWD del gioco.
    Copre .exe, .msi, .jar, documenti, URL, protocolli Steam (steam://), ecc."""
    try:
        subprocess.Popen(
            ["cmd", "/c", "start", "", target],
            cwd=cwd, shell=False, close_fds=False,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
            if hasattr(subprocess, "CREATE_NEW_PROCESS_GROUP") else 0,
        )
    except Exception:
        # ultimo tentativo: ShellExecute diretto
        os.startfile(target)  # noqa


def launch_game(path: str) -> tuple:
    """
    Avvia il gioco. Ritorna (ok, errore).

    Compatibilita' universale:
    - imposta SEMPRE la directory di lavoro alla cartella del gioco:
      molti engine (HaxeFlixel/FNF, Godot, ecc.) e i .bat di itch.io caricano
      asset con percorsi relativi: senza CWD corretta crashano o bugano;
    - .lnk/.url lanciati direttamente (Windows applica target/argomenti/CWD);
    - fallback "shell open" per qualunque altro tipo di file.
    """
    target = resolve_target(path)
    if not os.path.exists(target):
        return False, "file-not-found"
    # CWD = cartella che contiene l'eseguibile (o del collegamento, se il target
    # e' vuoto/non valido). Cosi' i giochi con asset relativi partono bene.
    cwd = os.path.dirname(os.path.abspath(path))
    if os.path.isfile(target):
        target_dir = os.path.dirname(os.path.abspath(target))
        if os.path.isdir(target_dir):
            cwd = target_dir
    try:
        low_orig = path.lower()
        if IS_WINDOWS:
            # .lnk / .url: lanciali direttamente: Windows gestisce target,
            # argomenti e cartella di lavoro salvati nel collegamento.
            # startfile vuole un percorso assoluto.
            if low_orig.endswith(".lnk") or low_orig.endswith(".url"):
                os.startfile(os.path.abspath(path))  # noqa
                return True, None
            low = target.lower()
            if low.endswith(".bat") or low.endswith(".cmd"):
                # i batch spesso usano percorsi relativi: serve CWD giusta
                _shell_open(target, cwd)
            else:
                try:
                    # .exe e altri binari: CWD obbligatoria per asset relativi
                    subprocess.Popen([target], cwd=cwd, close_fds=False)
                except OSError:
                    # tipo di file non eseguibile direttamente (jar, documenti,
                    # protocolli, ecc.): apri col gestore predefinito di Windows
                    _shell_open(target, cwd)
        else:
            if not os.access(target, os.X_OK) and target.lower().endswith((".sh", ".py")):
                subprocess.Popen(["/bin/sh", target], cwd=cwd, start_new_session=True)
            else:
                subprocess.Popen([target], cwd=cwd, start_new_session=True)
        return True, None
    except Exception as e:
        return False, str(e)


def extract_icon_bytes(path: str):
    """
    Estrae i byte dell'icona da un eseguibile (Windows PE via icoextract).
    Ritorna bytes ICO o None.
    """
    if not ICOEXTRACT_OK:
        return None
    try:
        target = resolve_target(path)
        # considera anche i .mun (pacchetti MS Store)
        if target.lower().endswith(".exe"):
            data = IconExtractor(target).get_icon()
            return data.getvalue()
    except Exception:
        pass
    return None


def default_db() -> dict:
    return {"games": [], "folders": [], "settings": {
        "language": "it",
        "background": None,
        "bg_dark": 0.55,
    }}


def shutoff_check(self):
    """No-op placeholder."""


# =====================================================================
# Test non-GUI
# =====================================================================
def human_list(items, sep=", "):
    return sep.join(items)


def selftest() -> int:
    """Test di integrità delle funzioni non-GUI."""
    print("== selftest GameVault ==")
    db = default_db()
    assert isinstance(db["games"], list)
    assert len(LANGUAGE_NAMES) == 11
    for code, table in I18N.items():
        assert code in LANGUAGE_NAMES, code
        for key in ("library", "settings", "add_game"):
            assert key in table, (code, key)
    # persistenza round-trip
    tmp_db = {"games": [{"id": "t1", "name": "Prova", "path": "x", "icon": None,
                         "folder": None, "fav": False, "runs": 0, "last": None}],
              "folders": ["F"], "settings": {"language": "en"}}
    save_db(tmp_db)
    loaded = load_db()
    assert loaded["games"][0]["name"] == "Prova"
    assert loaded["folders"] == ["F"]
    assert loaded["settings"]["language"] == "en"
    # pulizia
    try:
        os.remove(config_path())
    except OSError:
        pass
    print("OK: i18n (11 lingue), persistenza JSON, default db")
    return 0


# =====================================================================
# GUI
# =====================================================================
BG_CACHE = {}


def make_blurred_bg(path: str, width: int, height: int, darken: float = 0.55):
    """
    Sfondo sfocato REALE: cover-fit + GaussianBlur + velo scuro,
    preparato direttamente nell'immagine (nessun trucco overlay).
    Ritorna PhotoImage della dimensione esatta richiesta.
    """
    key = (path, width, height)
    if key in BG_CACHE:
        return BG_CACHE[key]
    img = Image.open(path).convert("RGB")
    sw, sh = img.size
    scale = max(width / sw, height / sh)
    img = img.resize((int(sw * scale) + 1, int(sh * scale) + 1), Image.LANCZOS)
    left = (img.width - width) // 2
    top = (img.height - height) // 2
    img = img.crop((left, top, left + width, top + height))
    img = img.filter(ImageFilter.GaussianBlur(16))
    if darken > 0:
        im = img.point(lambda v: int(v * (1.0 - darken)))
        img = im
    ph = ImageTk.PhotoImage(img)
    BG_CACHE.clear()
    BG_CACHE[key] = ph
    return ph


def icon_to_photo(path_or_bytes, size: int):
    """Carica un'icona (file o byte ICO) in un PhotoImage ridimensionato."""
    if not PIL_OK:
        return None
    try:
        if isinstance(path_or_bytes, (bytes, bytearray)):
            img = Image.open(io.BytesIO(path_or_bytes))
        else:
            img = Image.open(path_or_bytes)
        img = img.convert("RGBA")
        img = img.resize((size, size), Image.LANCZOS)
        return ImageTk.PhotoImage(img)
    except Exception:
        return None


class GameVaultApp:
    # palette moderna
    BG = "#0f1117"          # fondo generico
    CARD = "1e2230"         # card
    CARD_A = "#1e2230"
    CARD_HOVER = "#262b3d"
    SIDEBAR = "#14161f"
    HEADER = "#14161f"
    FG = "#e8e8f0"
    FG_DIM = "#9a9ab5"
    ACCENT = "#8f6cff"
    ACCENT_H = "#a485ff"

    F_BOX = ("Segoe UI", 10)
    F_TITLE = ("Segoe UI", 12, "bold")
    F_SIDEBAR = ("Segoe UI", 11)

    def __init__(self, root: tk.Tk):
        self.root = root
        self.db = load_db()
        self.root.title(APP_NAME)
        self.root.geometry("1120x700")
        self.root.minsize(880, 560)

        self.lang = self.db.get("settings", {}).get("language", "it")
        self._icons = {}          # PhotoImage cache per le card
        self._bg_photo = None
        self._hover_cards = {}
        self._resize_after = None

        self._build_styles()
        self._build_ui()
        self.apply_bg()
        self.root.bind("<Configure>", self._on_root_resize)

    # ------------------------------------------------ i18n
    # colori sempre validi per i widget SOPRA il blur
    FILTER_BG = "#181a24"        # barra filtri scurita uniforme
    FULL_CLEAR = "#101218"       # pannello vuoto/settings scuro pieno
    BG_TRANSPARENT_KEY = "#101218"  # bg del frame griglia (solo porta-widget)

    def tr(self, key, **kw) -> str:
        table = I18N.get(self.lang, I18N["it"])
        s = table.get(key) or I18N["en"].get(key) or key
        if kw:
            try:
                s = s.format(**kw)
            except (KeyError, IndexError, ValueError):
                pass
        return s

    def set_lang(self, code: str):
        if code in I18N:
            self.lang = code
            self.db.setdefault("settings", {})["language"] = code
            save_db(self.db)
            self._rebuild_ui()

    # ------------------------------------------------ stili
    def _build_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Sidebar.TFrame", background=self.SIDEBAR)
        style.configure("Header.TFrame", background=self.HEADER)
        style.configure("Card.TFrame", background=self.CARD_A)
        style.configure("Card.TLabel", background=self.CARD_A, foreground=self.FG)
        style.configure("Dim.TLabel", background=self.SIDEBAR, foreground=self.FG_DIM)
        style.configure("TLabelframe", background=self.CARD_A,
                        foreground=self.FG, borderwidth=0)
        style.configure("TLabelframe.Label", background=self.CARD_A,
                        foreground=self.FG_DIM, font=("Segoe UI", 10, "bold"))
        style.configure("TButton", padding=7, background=self.CARD_HOVER,
                        foreground=self.FG, borderwidth=0)
        style.map("TButton",
                  background=[("active", self.ACCENT)],
                  foreground=[("active", "#ffffff")])
        style.configure("TCheckbutton", background=self.SIDEBAR,
                        foreground=self.FG)
        style.map("TCheckbutton", background=[("active", self.SIDEBAR)])
        style.configure("TEntry", fieldbackground=self.CARD_HOVER,
                        foreground=self.FG, insertcolor=self.FG)
        style.configure("TCombobox", fieldbackground=self.CARD_HOVER,
                        background=self.CARD_HOVER, foreground=self.FG,
                        arrowcolor=self.FG)
        style.configure("Vertical.TScrollbar", background=self.CARD_HOVER,
                        troughcolor=self.BG, borderwidth=0)
        style.configure("TProgressbar", background=self.ACCENT,
                        troughcolor=self.CARD_HOVER)

    # ------------------------------------------------ UI
    def _build_ui(self):
        for w in self.root.winfo_children():
            w.destroy()
        self.root.configure(bg=self.BG)

        # ============ SIDEBAR
        self.sidebar = tk.Frame(self.root, bg=self.SIDEBAR, width=210)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        tk.Label(self.sidebar, text="◈ " + APP_NAME, bg=self.SIDEBAR,
                 fg=self.ACCENT, font=("Segoe UI", 15, "bold")
                 ).pack(anchor="w", padx=18, pady=(20, 24))

        self.btn_lib = tk.Label(self.sidebar, text="  ⌂  " + self.tr("library"),
                                bg=self.SIDEBAR, fg=self.FG, font=self.F_SIDEBAR,
                                anchor="w", cursor="hand2")
        self.btn_lib.pack(fill="x", pady=2)
        self.btn_lib.bind("<Button-1>", lambda e: self.show_library())

        self.btn_set = tk.Label(self.sidebar, text="  ⚙  " + self.tr("settings"),
                                bg=self.SIDEBAR, fg=self.FG, font=self.F_SIDEBAR,
                                anchor="w", cursor="hand2")
        self.btn_set.pack(fill="x", pady=2)
        self.btn_set.bind("<Button-1>", lambda e: self.show_settings())

        tk.Label(self.sidebar, text="", bg=self.SIDEBAR).pack(side="bottom",
                                                             pady=10)

        # ============ HEADER
        self.header = tk.Frame(self.root, bg=self.HEADER, height=64)
        self.header.pack(fill="x")
        self.header.pack_propagate(False)

        self.lbl_header = tk.Label(self.header, text=self.tr("library"),
                                   bg=self.HEADER, fg=self.FG,
                                   font=("Segoe UI", 14, "bold"))
        self.lbl_header.pack(side="left", padx=18)

        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self.refresh_grid())
        self.search_entry = tk.Entry(self.header, textvariable=self.search_var,
                                     bg=self.CARD_HOVER, fg=self.FG,
                                     insertbackground=self.FG, relief="flat",
                                     width=34, font=("Segoe UI", 10))
        self.search_entry.pack(side="right", padx=(0, 14), ipady=5)

        # bottone "+ Aggiungi gioco" (in alto a destra come richiesto)
        self.btn_add = tk.Label(self.header, text="＋ " + self.tr("add_game"),
                                bg=self.ACCENT, fg="#ffffff",
                                font=("Segoe UI", 10, "bold"), cursor="hand2",
                                padx=14, pady=6)
        self.btn_add.pack(side="right", padx=(0, 12))
        self.btn_add.bind("<Button-1>", lambda e: self.add_game_dialog())
        self.btn_add.bind("<Enter>",
                          lambda e: self.btn_add.configure(bg=self.ACCENT_H))
        self.btn_add.bind("<Leave>",
                          lambda e: self.btn_add.configure(bg=self.ACCENT))

        # ============ CORPO + SFONDO BLUR
        # Tecnica corretta: 1 solo Canvas “treno” che ospita (a) l’immagine
        # sfocata via create_image, (b) la window nascosta grid_frame su cui
        # stanno i contenuti. Niente Label/Frame-opachi che coprono il blur.
        self.body = tk.Frame(self.root, bg=self.BG)
        self.body.pack(fill="both", expand=True)

        self.bg_canvas = tk.Canvas(self.body, bg=self.BG, highlightthickness=0,
                                   bd=0)
        self.bg_canvas.pack(fill="both", expand=True)
        self._bg_img_id = None
        self._bg_photo = None

        # filtri: barretta scura semi-uniforme sovrapposta al blur
        fb_color = self.FILTER_BG
        filterbar = tk.Frame(self.bg_canvas, bg=fb_color, bd=0)
        self._fb_win = self.bg_canvas.create_window(
            0, 0, window=filterbar, anchor="nw", tags="filterbar")
        self.bg_canvas.bind("<Configure>",
                            lambda e: self.bg_canvas.itemconfigure(
                                self._fb_win, width=e.width))
        self.var_fav = tk.BooleanVar(value=False)
        self.chk_fav = ttk.Checkbutton(filterbar, text="★ " + self.tr("favorites_only"),
                                       variable=self.var_fav,
                                       command=self.refresh_grid)
        self.chk_fav.pack(side="left", padx=(4, 0))
        self.folder_var = tk.StringVar(value="")
        self.folder_menu = ttk.Combobox(filterbar, textvariable=self.folder_var,
                                        state="readonly", width=22)
        self.folder_menu.pack(side="left", padx=10)
        self.folder_menu.bind("<<ComboboxSelected>>",
                              lambda e: self.refresh_grid())
        ttk.Button(filterbar, text="🗂 " + self.tr("manage_folders"),
                   command=self.manage_folders_dialog).pack(side="left", padx=4)
        self.lbl_count = tk.Label(filterbar, text="", bg=fb_color, fg=self.FG_DIM,
                                  font=("Segoe UI", 9))
        self.lbl_count.pack(side="right")

        # griglia scrollabile: window dentro il canvas (sfondo visibile attorno)
        self.grid_frame = tk.Frame(self.bg_canvas, bg=self.BG_TRANSPARENT_KEY)
        self._grid_win = self.bg_canvas.create_window(
            0, 96, window=self.grid_frame, anchor="nw", tags="grid")
        self.bg_canvas.bind("<Configure>", self._on_canvas_resize)

        self.current_view = "library"
        self.refresh_grid()
        self._mark_sidebar(self.btn_lib)

    def _mark_sidebar(self, item):
        for b in (self.btn_lib, self.btn_set):
            b.configure(bg=self.SIDEBAR, fg=self.FG_DIM)
        if item:
            item.configure(bg="#20242f", fg=self.ACCENT)

    def _mousewheel_bind(self):
        self.bg_canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _on_mousewheel(self, e):
        self.bg_canvas.yview_scroll(int(-e.delta / 120), "units")

    def _on_canvas_resize(self, e):
        self.bg_canvas.itemconfigure(self._grid_win, width=e.width)

    def _on_root_resize(self, e):
        # redraw sfondo al ridimensionamento (debounced)
        if e.widget is self.root and self.db.get("settings", {}).get("background"):
            if self._resize_after:
                self.root.after_cancel(self._resize_after)
            self._resize_after = self.root.after(180, self.apply_bg)

    # ------------------------------------------------ sfondo
    def apply_bg(self):
        """Disegna il blur DENTRO il canvas (dietro window e filtri)."""
        bg = self.db.get("settings", {}).get("background")
        try:
            self.root.update_idletasks()
            w = max(self.bg_canvas.winfo_width(), 400)
            h = max(self.bg_canvas.winfo_height(), 300)
        except Exception:
            w, h = 1120, 700
        if self._bg_img_id is not None:
            try:
                self.bg_canvas.delete(self._bg_img_id)
            except tk.TclError:
                pass
            self._bg_img_id = None
        if bg and PIL_OK and os.path.exists(bg):
            try:
                self._bg_photo = make_blurred_bg(bg, w, h, darken=0.55)
                # create_image PRIMA delle windows in ordine di stacking:
                # lo mettiamo in fondo con tag="bg"
                self._bg_img_id = self.bg_canvas.create_image(
                    0, 0, image=self._bg_photo, anchor="nw", tags="bg")
                self.bg_canvas.tag_lower("bg")   # specchia tutto all’indietro
            except Exception:
                pass
        else:
            self._bg_photo = None

    def _rebuild_ui(self):
        self._build_ui()
        self.apply_bg()

    # ------------------------------------------------ libreria
    def filtered_games(self):
        q = (self.search_var.get() or "").lower().strip()
        fav = self.var_fav.get()
        folder = self.folder_var.get()
        games = self.db["games"]
        out = []
        for g in games:
            if fav and not g.get("fav"):
                continue
            if folder and g.get("folder") != folder:
                continue
            if q and q not in (g.get("name", "").lower()):
                continue
            out.append(g)
        out.sort(key=lambda g: g.get("name", "").lower())
        return out

    def refresh_grid(self):
        if self.current_view != "library":
            return
        # la griglia deve stare SOPRA lo sfondo ma SOTTO i filtri
        self.bg_canvas.tag_raise("grid")
        self.bg_canvas.tag_raise("filterbar")
        games = self.filtered_games()
        # filtri: genera menu cartelle
        folders = [""] + sorted(self.db["folders"])
        current = self.folder_var.get()
        vals = [self.tr("all")] + list(folders[1:])
        self.folder_menu.configure(values=vals)
        if current not in folders:
            self.folder_var.set("")
        elif current:
            self.folder_var.set(current)
        if not self.folder_var.get():
            self.folder_var.set("")
        shown = self.tr("all") if self.folder_var.get() == "" else self.folder_var.get()
        self.lbl_count.configure(
            text=f"{len(games)} · {shown}")

        for w in self.grid_frame.winfo_children():
            w.destroy()
        self._icons.clear()
        self._hover_cards.clear()

        if not games:
            empty = tk.Frame(self.grid_frame, bg=self.FULL_CLEAR)
            empty.pack(fill="x", pady=60)
            tk.Label(empty, text="🎮", bg=self.FULL_CLEAR, fg=self.FG_DIM,
                     font=("Segoe UI", 40)).pack()
            tk.Label(empty, text=self.tr("no_results"), bg=self.FULL_CLEAR,
                     fg=self.FG_DIM, font=("Segoe UI", 11)).pack()
            return

        self.grid_frame.update_idletasks()
        width = max(self.bg_canvas.winfo_width(), 300)
        ncols = max(2, width // 250)
        for i, g in enumerate(games):
            card = self._make_card(g)
            r, c = divmod(i, ncols)
            card.grid(row=r, column=c, padx=8, pady=8, sticky="nsew")
        for c in range(ncols):
            self.grid_frame.columnconfigure(c, weight=1)

    def _make_card(self, g):
        card = tk.Frame(self.grid_frame, bg=self.CARD_A, bd=0,
                        highlightthickness=1,
                        highlightbackground="#2a2f44",
                        highlightcolor=self.ACCENT)
        # icona grande centrata (sopra)
        icon_row = tk.Frame(card, bg=self.CARD_A)
        icon_row.pack(fill="x", pady=(14, 6))
        ph = None
        icon = g.get("icon")
        if icon and os.path.exists(icon):
            ph = icon_to_photo(icon, 92)
        if ph:
            self._icons[id(g)] = ph
            lbl_icon = tk.Label(icon_row, image=ph, bg=self.CARD_A)
        else:
            lbl_icon = tk.Label(icon_row, text="🎮", bg=self.CARD_A,
                                fg=self.FG_DIM, font=("Segoe UI", 34))
        lbl_icon.pack()
        # stella preferito in alto a destra
        if g.get("fav"):
            tk.Label(card, text="★", bg=self.CARD_A, fg="#ffcc44",
                     font=("Segoe UI", 13)).place(relx=1.0, x=-10, y=6,
                                                  anchor="ne")
        # nome + cartella
        tk.Label(card, text=g.get("name", "?"), bg=self.CARD_A, fg=self.FG,
                 font=self.F_TITLE).pack(fill="x", padx=12)
        folder = g.get("folder") or self.tr("no_folder")
        tk.Label(card, text=folder, bg=self.CARD_A, fg=self.FG_DIM,
                 font=("Segoe UI", 9)).pack(fill="x", padx=12, pady=(0, 6))
        # stat runs
        tk.Label(card,
                 text=self.tr("run_count", n=g.get("runs", 0)),
                 bg=self.CARD_A, fg="#8a8aa8",
                 font=("Segoe UI", 8)).pack(fill="x", padx=12)
        # bottoni azione
        btns = tk.Frame(card, bg=self.CARD_A)
        btns.pack(fill="x", padx=10, pady=(8, 12))

        def mk_btn(parent, text, fg, cmd, padx=(0, 4)):
            b = tk.Label(parent, text=text, bg="#2a2f44", fg=fg,
                         font=("Segoe UI", 11), cursor="hand2",
                         padx=12, pady=4)
            b.pack(side="left", padx=padx)
            b.bind("<Button-1>", lambda e: cmd())
            b.bind("<Enter>", lambda e: b.configure(bg=self.ACCENT, fg="white"))
            b.bind("<Leave>", lambda e: b.configure(bg="#2a2f44", fg=fg))
            return b

        mk_btn(btns, "▶", "#ffffff", lambda: self.launch(g), padx=(0, 0))
        mk_btn(btns, "★" if g.get("fav") else "☆", "#ffcc44",
               lambda: self.toggle_fav(g))
        mk_btn(btns, "✎", self.FG_DIM, lambda: self.edit_game(g))
        mk_btn(btns, "🗑", "#ff7788", lambda: self.remove_game(g))

        # hover sulla card intera
        card.bind("<Enter>",
                  lambda e, c=card: c.configure(bg=self.CARD_HOVER,))
        card.bind("<Leave>",
                  lambda e, c=card: c.configure(bg=self.CARD_A))
        return card

    def launch(self, g):
        ok, err = launch_game(g["path"])
        if ok:
            g["runs"] = g.get("runs", 0) + 1
            g["last"] = datetime.datetime.now().isoformat(timespec="seconds")
            save_db(self.db)
        else:
            messagebox.showerror(
                self.tr("error_generic"),
                self.tr("launch_fail", path=g["path"]) + (f"\n{err}" if err else ""),
            )

    def toggle_fav(self, g):
        g["fav"] = not g.get("fav", False)
        save_db(self.db)
        self.refresh_grid()

    def remove_game(self, g):
        if messagebox.askyesno(self.tr("remove"), self.tr("remove_confirm", name=g.get("name", ""))):
            self.db["games"] = [x for x in self.db["games"] if x.get("id") != g.get("id")]
            save_db(self.db)
            self.refresh_grid()

    # ------------------------------------------------ aggiungi/modifica
    def add_game_dialog(self):
        self._game_dialog(None)

    def edit_game(self, g):
        self._game_dialog(g)

    def _game_dialog(self, existing):
        win = tk.Toplevel(self.root)
        win.title(self.tr("edit_title") if existing else self.tr("add_game_title"))
        win.transient(self.root)
        win.grab_set()
        win.configure(bg=self.CARD_A)
        win.geometry("560x420")

        state = {"path": existing.get("path", "") if existing else "",
                 "icon": existing.get("icon") if existing else None,
                 "name": existing.get("name", "") if existing else "",
                 "folder": existing.get("folder") if existing else None,
                 "fav": existing.get("fav", False) if existing else False}

        # --- passo 1: eseguibile
        ttk.Label(win, text=self.tr("choose_exe"), style="Card.TLabel").pack(
            anchor="w", padx=16, pady=(16, 4))
        row1 = ttk.Frame(win, style="Card.TFrame")
        row1.pack(fill="x", padx=16)
        var_path = tk.StringVar(value=state["path"])
        ttk.Entry(row1, textvariable=var_path).pack(side="left", fill="x",
                                                    expand=True, ipady=4)

        def browse_exe():
            if IS_WINDOWS:
                filetypes = [("Eseguibili/Collegamenti", "*.exe *.lnk *.url *.bat *.cmd"),
                             ("Tutti i file", "*.*")]
            else:
                filetypes = [("Tutti i file", "*")]
            p = filedialog.askopenfilename(parent=win, filetypes=filetypes)
            if p:
                var_path.set(p)

        def pick_icon(artist_path=""):
            """Prova icona automatica dall'exe; altrimenti ritorna None."""
            if not artist_path:
                return None
            b = extract_icon_bytes(artist_path)
            if b:
                return save_icon_file(b)
            return None

        ttk.Button(row1, text=self.tr("browse"), command=browse_exe).pack(
            side="left", padx=(8, 0))

        # --- passo 2: icona
        ttk.Label(win, text=self.tr("choose_icon"), style="Card.TLabel").pack(
            anchor="w", padx=16, pady=(14, 4))
        row2 = ttk.Frame(win, style="Card.TFrame")
        row2.pack(fill="x", padx=16)
        icon_preview = tk.Label(row2, bg=self.CARD_A, width=48, height=48)
        icon_preview.pack(side="left")
        icon_state = {"bytes": state["icon"]}

        def refresh_preview():
            ph = None
            if icon_state["bytes"]:
                ph = icon_to_photo(icon_state["bytes"], 48)
            elif state["icon"] and os.path.exists(state["icon"]):
                ph = icon_to_photo(state["icon"], 48)
            if ph:
                icon_preview.configure(image=ph, text="")
                win._icon_ph = ph  # tienilo vivo
            else:
                icon_preview.configure(image="", text="?")

        def use_auto_icon():
            b = extract_icon_bytes(var_path.get())
            if b:
                icon_state["bytes"] = b
                state["icon"] = save_icon_file(b)
                refresh_preview()
            else:
                messagebox.showinfo(self.tr("choose_icon"),
                                    self.tr("icon_extract_fail"), parent=win)

        def pick_icon_file():
            p = filedialog.askopenfilename(
                parent=win,
                filetypes=[("Immagini", "*.png *.jpg *.jpeg *.gif *.bmp *.ico *.webp"),
                           ("Tutti i file", "*.*")])
            if p:
                state["icon"] = p
                icon_state["bytes"] = None
                refresh_preview()

        ttk.Button(row2, text=self.tr("icon_auto"), command=use_auto_icon).pack(
            side="left", padx=(10, 4))
        ttk.Button(row2, text=self.tr("icon_file"), command=pick_icon_file).pack(
            side="left", padx=4)

        # --- passo 3: nome + cartella
        ttk.Label(win, text=self.tr("choose_name"), style="Card.TLabel").pack(
            anchor="w", padx=16, pady=(14, 4))
        row3 = ttk.Frame(win, style="Card.TFrame")
        row3.pack(fill="x", padx=16)
        var_name = tk.StringVar(value=state["name"])
        ttk.Entry(row3, textvariable=var_name).pack(side="left", fill="x",
                                                    expand=True, ipady=4)
        var_folder = tk.StringVar(value=state["folder"] or "")

        folder_row = ttk.Frame(win, style="Card.TFrame")
        folder_row.pack(fill="x", padx=16, pady=(8, 0))
        ttk.Label(folder_row, text=self.tr("folder_label"), style="Card.TLabel").pack(side="left")
        folder_vals = [""] + sorted(self.db["folders"])
        folder_cb = ttk.Combobox(folder_row, textvariable=var_folder,
                                 values=folder_vals, state="readonly", width=22)
        folder_cb.pack(side="left", padx=8)

        def new_folder_inline():
            name = simpledialog.askstring(
                self.tr("new_folder"), self.tr("name_label"), parent=win)
            if name and name.strip():
                name = name.strip()
                if name not in self.db["folders"]:
                    self.db["folders"].append(name)
                    save_db(self.db)
                folder_cb.configure(values=[""] + sorted(self.db["folders"]))
                var_folder.set(name)

        ttk.Button(folder_row, text="+", command=new_folder_inline).pack(side="left")

        var_fav = tk.BooleanVar(value=state["fav"])
        c = ttk.Checkbutton(folder_row, text="★ " + self.tr("favorite"),
                            variable=var_fav)
        c.pack(side="left", padx=8)

        refresh_preview()

        # --- bottoni
        btnrow = ttk.Frame(win, style="Card.TFrame")
        btnrow.pack(side="bottom", fill="x", padx=16, pady=12)
        ttk.Button(btnrow, text=self.tr("cancel"), command=win.destroy).pack(side="right")

        def do_save():
            path = var_path.get().strip()
            name = var_name.get().strip()
            if not path:
                messagebox.showerror(self.tr("error_generic"),
                                     self.tr("err_missing_exe"), parent=win)
                return
            if not name:
                messagebox.showerror(self.tr("error_generic"),
                                     self.tr("err_bad_name"), parent=win)
                return
            data = {"id": existing["id"] if existing else f"g{int(datetime.datetime.now().timestamp()*1000)}",
                    "name": name, "path": path, "icon": state["icon"],
                    "folder": var_folder.get() or None,
                    "fav": var_fav.get(),
                    "runs": existing.get("runs", 0) if existing else 0,
                    "last": existing.get("last") if existing else None}
            if existing:
                for i, x in enumerate(self.db["games"]):
                    if x.get("id") == existing["id"]:
                        self.db["games"][i] = data
                        break
            else:
                self.db["games"].append(data)
            save_db(self.db)
            win.destroy()
            self.refresh_grid()

        ttk.Button(btnrow, text=self.tr("save"), command=do_save).pack(
            side="right", padx=8)

    # ------------------------------------------------ cartelle
    def manage_folders_dialog(self):
        win = tk.Toplevel(self.root)
        win.title(self.tr("manage_folders"))
        win.transient(self.root)
        win.grab_set()
        win.configure(bg=self.CARD_A)
        win.geometry("420x380")
        lst = tk.Listbox(win, bg=self.CARD_A, fg=self.FG,
                         highlightthickness=0, selectbackground=self.ACCENT,
                         selectforeground="#ffffff")
        lst.pack(fill="both", expand=True, padx=12, pady=12)

        def reload():
            lst.delete(0, "end")
            for f in sorted(self.db["folders"]):
                lst.insert("end", f)

        reload()

        # contenitore scorrevole per i giochi di una cartella (nessun cambiamento
        # funzionale: rinomina/elimina come prima, ma i figli restano collegati)
        def sel():
            i = lst.curselection()
            return lst.get(i) if i else None

        def rename():
            f = sel()
            if not f:
                return
            new = simpledialog.askstring(self.tr("rename_folder"), f, parent=win,
                                         initialvalue=f)
            if new and new.strip() and new not in self.db["folders"]:
                new = new.strip()
                for g in self.db["games"]:
                    if g.get("folder") == f:
                        g["folder"] = new
                self.db["folders"].remove(f)
                self.db["folders"].append(new)
                save_db(self.db)
                reload()
                self.refresh_grid()

        def delete():
            f = sel()
            if not f:
                return
            if messagebox.askyesno(self.tr("delete_folder"),
                                   self.tr("delete_folder_confirm", name=f), parent=win):
                for g in self.db["games"]:
                    if g.get("folder") == f:
                        g["folder"] = None
                self.db["folders"].remove(f)
                save_db(self.db)
                reload()
                self.refresh_grid()

        ttk.Button(win, text=self.tr("rename_folder"), command=rename).pack(
            side="left", padx=(12, 4), pady=(0, 12))
        ttk.Button(win, text=self.tr("delete_folder"), command=delete).pack(
            side="left", padx=4, pady=(0, 12))
        ttk.Button(win, text=self.tr("close"), command=win.destroy).pack(
            side="right", padx=12, pady=(0, 12))

    # ------------------------------------------------ impostazioni
    def show_settings(self):
        """Vista Impostazioni dentro il corpo principale (niente popup bianchi)."""
        self.current_view = "settings"
        self._mark_sidebar(self.btn_set)
        self.lbl_header.configure(text=self.tr("settings"))
        self.search_entry.pack_forget()          # nascondi ricerca in settings
        self.btn_add.pack_forget()               # niente aggiunta in settings
        # svuota la griglia e costruisci il pannello impostazioni dentro body
        for w in self.grid_frame.winfo_children():
            w.destroy()
        # nascondi la barra filtri (tags del canvas)
        self.bg_canvas.itemconfigure(self._fb_win, state="hidden")
        # porta la griglia in alto (offset iniziale non serve in settings)
        self.bg_canvas.coords(self._grid_win, 0, 0)

        self._settings_panel = tk.Frame(self.grid_frame, bg=self.FULL_CLEAR)
        self._settings_panel.pack(fill="both", expand=True, padx=24, pady=18)

        card = tk.Frame(self._settings_panel, bg=self.CARD_A, bd=0,
                        highlightthickness=1, highlightbackground="#2a2f44")
        card.pack(fill="x", pady=(0, 14))

        tk.Label(card, text=self.tr("language"), bg=self.CARD_A,
                 fg=self.FG, font=self.F_TITLE, anchor="w").pack(
            fill="x", padx=16, pady=(14, 4))
        lang_var = tk.StringVar(value=LANGUAGE_NAMES[self.lang])
        langs = [(LANGUAGE_NAMES[c], c) for c in sorted(I18N)]

        def on_lang(e=None):
            for c, n in LANGUAGE_NAMES.items():
                if n == lang_var.get():
                    self.set_lang(c)
                    break

        cb = ttk.Combobox(card, textvariable=lang_var,
                          values=[n for n, _ in langs],
                          state="readonly", width=24)
        cb.pack(anchor="w", padx=16, pady=(0, 6))
        cb.bind("<<ComboboxSelected>>", on_lang)

        tk.Label(card, text=self.tr("background"), bg=self.CARD_A,
                 fg=self.FG, font=self.F_TITLE, anchor="w").pack(
            fill="x", padx=16, pady=(14, 4))

        def pick_bg():
            p = filedialog.askopenfilename(
                filetypes=[("Immagini", "*.png *.jpg *.jpeg *.webp *.bmp *.ico"),
                           ("Tutti i file", "*.*")])
            if p:
                self.db.setdefault("settings", {})["background"] = p
                save_db(self.db)
                self._set_bg_state()

        def clear_bg():
            self.db.setdefault("settings", {})["background"] = None
            save_db(self.db)
            self._set_bg_state()

        self._bg_state_lbl = tk.Label(card, text="", bg=self.CARD_A,
                                      fg=self.FG_DIM, font=("Segoe UI", 9))
        brow = tk.Frame(card, bg=self.CARD_A)
        brow.pack(anchor="w", padx=16, pady=(0, 4))
        ttk.Button(brow, text=self.tr("change_bg"), command=pick_bg).pack(
            side="left", padx=(0, 6))
        ttk.Button(brow, text=self.tr("remove_bg"), command=clear_bg).pack(side="left")
        self._bg_state_lbl.pack(anchor="w", padx=16, pady=(2, 10))
        self._set_bg_state()

        tk.Label(card, text=self.tr("bg_info"), bg=self.CARD_A,
                 fg=self.FG_DIM, font=("Segoe UI", 9), anchor="w",
                 wraplength=480, justify="left").pack(fill="x", padx=16, pady=(0, 12))

        info = tk.Frame(self._settings_panel, bg=self.FULL_CLEAR)
        info.pack(fill="both", expand=True)
        tk.Label(info, text=self.tr("data_note", path=config_path()),
                 bg=self.FULL_CLEAR, fg=self.FG_DIM,
                 font=("Segoe UI", 9), anchor="nw",
                 wraplength=520, justify="left").pack(anchor="w")
        self.bg_canvas.tag_raise("grid")

    def _set_bg_state(self):
        bg = self.db.get("settings", {}).get("background")
        if self._bg_state_lbl.winfo_exists():
            self._bg_state_lbl.configure(
                text=os.path.basename(bg) if bg else "—")

    def show_library(self):
        self.current_view = "library"
        self._mark_sidebar(self.btn_lib)
        self.lbl_header.configure(text=self.tr("library"))
        # ripristina ricerca e bottone aggiungi
        self.search_entry.pack_forget()
        self.btn_add.pack_forget()
        self.btn_add.pack(side="right", padx=(0, 12))
        self.search_entry.pack(side="right", padx=(0, 14), ipady=5)
        # rimuovi il pannello impostazioni se esiste
        if getattr(self, "_settings_panel", None) is not None:
            try:
                self._settings_panel.destroy()
            except tk.TclError:
                pass
            self._settings_panel = None
        # ripristina filtri e offset griglia
        self.bg_canvas.itemconfigure(self._fb_win, state="normal")
        self.bg_canvas.coords(self._grid_win, 0, 96)
        self.bg_canvas.tag_raise("grid")
        self.bg_canvas.tag_raise("filterbar")
        self.refresh_grid()


def save_icon_file(ico_bytes: bytes) -> str:
    """Salva i byte ICO in ~/.gamevault/icons/ e ritorna il percorso."""
    d = os.path.join(config_dir(), "icons")
    os.makedirs(d, exist_ok=True)
    name = f"icon_{int(datetime.datetime.now().timestamp()*1000)}.ico"
    p = os.path.join(d, name)
    with open(p, "wb") as f:
        f.write(ico_bytes)
    return p


def main() -> int:
    ap = argparse.ArgumentParser(prog="gamelauncher.py", description=APP_NAME)
    ap.add_argument("--selftest", action="store_true",
                    help="esegue i test non-GUI ed esce")
    args = ap.parse_args()
    if args.selftest:
        return selftest()
    if not TK_OK:
        print("tkinter non disponibile", file=sys.stderr)
        return 1
    root = tk.Tk()
    app = GameVaultApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
